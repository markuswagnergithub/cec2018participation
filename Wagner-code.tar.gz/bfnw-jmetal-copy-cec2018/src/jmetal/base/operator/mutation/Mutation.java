/*
 * Mutation.java
 * @author Juan J. Durillo
 * @version 1.0
 *
 * This class represents the super class of all the mutations operators
 */

package jmetal.base.operator.mutation;

import jmetal.base.Operator;


public abstract class Mutation extends Operator {


} // Mutation
