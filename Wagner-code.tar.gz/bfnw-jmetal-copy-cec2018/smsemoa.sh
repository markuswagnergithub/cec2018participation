cd bfnw/

java jmetal.metaheuristics.smsemoa.SMSEMOA $1 $2 $3 $4 $5 $6 $7
